package com.kenzy.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class KenzyService : Service(), RecognitionListener {
    private var rec: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private val h = Handler(Looper.getMainLooper())
    private var awaitingUntil = 0L
    private val wake = Regex("\\b(kenzy|kenzie|kenzi|quenzy|kensi|kenzi)\\b")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        val ch = "kenzy"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Kenzy", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Kenzy écoute")
            .setContentText("Dites « Kenzy » + votre demande")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this) { tts.language = Locale.FRENCH }
        listen()
    }

    private fun listen() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(this)
            it.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR"))
        }
    }

    override fun onResults(r: Bundle?) {
        val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
        val m = wake.find(text)
        val now = System.currentTimeMillis()
        val cmd = when {
            m != null -> text.substring(m.range.last + 1).trim()
            now < awaitingUntil -> text.trim()
            else -> null
        }
        if (cmd != null) {
            if (cmd.isEmpty()) { awaitingUntil = now + 8000; say("Oui ?") }
            else { awaitingUntil = 0; say(CommandHandler.run(this, cmd)) }
        }
        h.postDelayed({ listen() }, 400)
    }

    override fun onError(e: Int) { h.postDelayed({ listen() }, 800) }
    private fun say(s: String) { tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "k") }
    override fun onDestroy() { rec?.destroy(); tts.shutdown() }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(t: Int, p: Bundle?) {}
}
