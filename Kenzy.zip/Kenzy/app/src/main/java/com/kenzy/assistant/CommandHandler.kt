package com.kenzy.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri

object CommandHandler {
    private fun go(c: Context, i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) }
    private fun url(c: Context, u: String) = go(c, Intent(Intent.ACTION_VIEW, Uri.parse(u)))

    fun openApp(c: Context, name: String): Boolean {
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val app = list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        go(c, pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return false)
        return true
    }

    /** Exécute la commande et renvoie la phrase que Kenzy prononce. */
    fun run(c: Context, cmd: String): String {
        val t = cmd.lowercase().trim()
        val acc = KenzyAccessibility.instance
        return when {
            Regex("^(ouvre|ouvrir|lance|lancer)\\s+(.+)").find(t) != null -> {
                val n = Regex("^(ouvre|ouvrir|lance|lancer)\\s+(l'application |la |le |l')?(.+)").find(t)!!.groupValues[3]
                if (openApp(c, n)) "J'ouvre $n" else "Je ne trouve pas $n"
            }
            t.startsWith("youtube") || t.contains("sur youtube") -> {
                val q = t.replace("sur youtube", "").replace("youtube", "").trim()
                url(c, "https://www.youtube.com/results?search_query=" + Uri.encode(q)); "Recherche YouTube"
            }
            t.startsWith("va sur ") || t.startsWith("aller sur ") -> {
                val s = t.substringAfter("sur ").replace(" ", "").replace("point", ".")
                url(c, if (s.startsWith("http")) s else "https://$s"); "J'y vais"
            }
            t.startsWith("appelle ") && t.any { it.isDigit() } -> {
                go(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + t.filter { it.isDigit() }))); "J'appelle"
            }
            t == "retour" || t == "reviens" -> { acc?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK); "D'accord" }
            t == "accueil" || t == "maison" -> { acc?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME); "D'accord" }
            t.startsWith("clique sur ") -> if (acc?.clickText(t.removePrefix("clique sur ")) == true) "Fait" else "Je ne vois pas ça"
            t.startsWith("cherche ") || t.startsWith("recherche ") -> {
                go(c, Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", t.substringAfter(" "))); "Je cherche"
            }
            t.isEmpty() -> "Oui ?"
            else -> { url(c, "https://www.google.com/search?q=" + Uri.encode(t)); "Je cherche sur le web" }
        }
    }
}
