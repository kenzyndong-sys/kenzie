package com.kenzy.assistant

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, a: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        l.addView(TextView(this).apply { text = "Kenzy"; textSize = 32f })
        btn("1. Autoriser micro + notifications") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("2. Autoriser l'affichage par-dessus") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Activer l'accessibilité (contrôle)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("4. Démarrer Kenzy") { startForegroundService(Intent(this, KenzyService::class.java)) }
        btn("Arrêter Kenzy") { stopService(Intent(this, KenzyService::class.java)) }
        setContentView(l)
    }
}
